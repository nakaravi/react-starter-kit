{

	"ExternalData": [
		{
			"resultTxt_1":{
				"text" :""
			},
			"resultTxt_2":{
				"text" :""
			},
			"scoreTxt":{
				"text" :"You scored "
			},
			"solutionTxt":{
				"text" :"Solution."
			},
			"btnTxt_1":{
				"text" :"Review Answers"
			},
			"btnTxt_2":{
				"text" :"Retake Quiz"
			}
			, "feedbackAboveTxt_1":{ "text" :"Congratulations!" }, "feedbackBelowTxt_1":{ "text" :"Failed" }, "feedbackAboveTxt_2":{ "text" :"Congratulations!" }, "feedbackBelowTxt_2":{ "text" :"You can do better!" }, "detail_score":{ "text" :"1"}, "onlyScore":{ "text" : ""}, "question_list_Both":{ "text" : "true"}, "no_of_right_answer":{ "text" : "1"}, "mastery_score":{ "text" : "80"}
			

		}
	]
}	
			