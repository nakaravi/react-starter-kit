{

	"ExternalData": [
		{
			"headingTxt":{
				"text" :"ES40ACi - Electrical Systems - Basic"
			},
			"introText_1":{
				"text" :""
			}

		}
	]
}	
			